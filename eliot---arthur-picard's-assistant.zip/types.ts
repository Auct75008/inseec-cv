
export enum ConnectionStatus {
  IDLE = 'IDLE',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  ERROR = 'ERROR',
  DISCONNECTED = 'DISCONNECTED'
}

export interface TranscriptionEntry {
  text: string;
  type: 'user' | 'model';
  timestamp: number;
}

export interface CVEntry {
  id: string;
  name: string;
  content: string;
  type: 'pdf' | 'text' | 'default';
}
