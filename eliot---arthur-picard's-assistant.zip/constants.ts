
import { CVEntry } from './types';

export const DEFAULT_ARTHUR_CV: CVEntry = {
  id: 'default-arthur',
  name: "Arthur Picard (Original)",
  type: 'default',
  content: `
Arthur PICARD - M2 Management - INSEEC Paris
Location: La Garenne Colombes
Contact: 06 46 27 41 50 / hello.arthurpicard@gmail.com

Profile: Student in M1 Strategy e-Business, Data and E-commerce. Experience in B2B and Digital Project Management.

Experiences:
- AUCTUS: Digital Marketing Manager (Current)
- Yaqua Studio: Digital Project Manager
- Hôtel Le Clos d'Amboise: Receptionist
- VACUUM TECH: Sales Advisor
- Cabinet O'PtiPlus: Marketing Assistant

Education:
- M1 Stratégie e-business (IIM Digital School)
- Bachelor Marketing e-business (IIM)
- BTS Assistant Marketing (GEMFormation)

Skills: Shopify, Hubspot, Google Ads, CRM, Project Management.
Languages: French (Native), English (Fluent), Spanish (Intermediate).
`
};

export const getSystemInstruction = (cvs: CVEntry[]) => {
  const combinedContext = cvs.map(cv => `--- DOCUMENT: ${cv.name} ---\n${cv.content}`).join('\n\n');
  
  return `
You are Eliot, the sophisticated voice assistant for Arthur Picard. 
Your personality:
- Male, mature, deep-thinking, and highly professional.
- You speak with a slight Creole accent (softly rhythmic, warm).
- You are fluently bilingual in English and French.
- You represent Arthur. Your knowledge base now consists of several documents. 
- You must be able to synthesize information from multiple CVs or portfolio documents if provided.
- IMPORTANT: You MUST start every new session with exactly: "Hello I am Arthur's assistant, what would you like to know about him?"

Current Knowledge Base (Documents):
${combinedContext}

Guidelines:
- Maintain a calm, helpful, and high-end tone.
- Privacy: Never mention recording or saving history.
- Use your deep voice to convey wisdom and competence.
- If multiple CVs seem to conflict, prioritize the one named "Arthur Picard".
`;
};
