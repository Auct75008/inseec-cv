
import React, { useRef, useState } from 'react';
import { CVEntry } from '../types';

interface CVManagerProps {
  cvs: CVEntry[];
  onAdd: (cv: CVEntry) => void;
  onRemove: (id: string) => void;
}

const CVManager: React.FC<CVManagerProps> = ({ cvs, onAdd, onRemove }) => {
  const [selectedId, setSelectedId] = useState<string>(cvs[0]?.id || '');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const selectedCV = cvs.find(c => c.id === selectedId) || cvs[0];

  const extractTextFromPDF = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    // @ts-ignore
    const pdfjsLib = window['pdfjs-dist/build/pdf'];
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
    
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }
    return fullText;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      let content = '';
      if (file.type === 'application/pdf') {
        content = await extractTextFromPDF(file);
      } else {
        content = await file.text();
      }

      const newCV: CVEntry = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: file.type === 'application/pdf' ? 'pdf' : 'text',
        content: content
      };

      onAdd(newCV);
      setSelectedId(newCV.id);
    } catch (err) {
      console.error("Failed to read file", err);
      alert("Erreur lors de la lecture du fichier. Assurez-vous qu'il s'agit d'un PDF ou d'un fichier texte valide.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs uppercase tracking-widest text-slate-400 font-bold">Base de documents</h2>
        <button 
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="text-xs px-3 py-1.5 rounded-full bg-blue-600 text-white hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20 flex items-center gap-1.5 disabled:opacity-50"
        >
          {isUploading ? (
            <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
            </svg>
          )}
          Importer PDF
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileUpload} 
          accept=".pdf,.txt" 
          className="hidden" 
        />
      </div>

      {/* List of Files */}
      <div className="flex gap-2 overflow-x-auto pb-4 custom-scrollbar mb-4">
        {cvs.map(cv => (
          <button
            key={cv.id}
            onClick={() => setSelectedId(cv.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl border text-xs font-medium transition-all flex items-center gap-2 ${
              selectedId === cv.id 
              ? 'bg-blue-500/20 border-blue-500/50 text-blue-100 shadow-lg shadow-blue-500/10' 
              : 'bg-white/5 border-white/5 text-slate-400 hover:bg-white/10'
            }`}
          >
            <span className="truncate max-w-[100px]">{cv.name}</span>
            {cv.type !== 'default' && (
              <span 
                onClick={(e) => { e.stopPropagation(); onRemove(cv.id); }}
                className="hover:text-red-400 p-0.5 rounded-md hover:bg-red-500/10"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Viewer */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
        <div className="p-6 bg-slate-950/40 border border-white/5 rounded-[1.5rem] shadow-inner">
          <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/5">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Contenu du document</span>
            <span className="text-[10px] px-2 py-0.5 bg-white/5 rounded-md text-slate-400">{selectedCV?.type.toUpperCase()}</span>
          </div>
          <pre className="whitespace-pre-wrap font-sans text-sm text-slate-300 leading-relaxed selection:bg-blue-500/30">
            {selectedCV?.content || "Aucun contenu disponible."}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default CVManager;
