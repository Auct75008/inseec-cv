
import React, { useEffect, useState } from 'react';

interface VoiceOrbProps {
  active: boolean;
  status: string;
}

const VoiceOrb: React.FC<VoiceOrbProps> = ({ active, status }) => {
  const [scale, setScale] = useState(1);

  useEffect(() => {
    let interval: number;
    if (active) {
      interval = window.setInterval(() => {
        setScale(1 + Math.random() * 0.2);
      }, 100);
    } else {
      setScale(1);
    }
    return () => clearInterval(interval);
  }, [active]);

  const getOrbColor = () => {
    switch (status) {
      case 'CONNECTED': return 'from-blue-400 to-indigo-600 shadow-[0_0_50px_rgba(59,130,246,0.5)]';
      case 'CONNECTING': return 'from-yellow-400 to-orange-500 shadow-[0_0_50px_rgba(245,158,11,0.5)] animate-pulse';
      case 'ERROR': return 'from-red-500 to-rose-700 shadow-[0_0_50px_rgba(239,68,68,0.5)]';
      default: return 'from-slate-600 to-slate-800 shadow-[0_0_30px_rgba(71,85,105,0.3)]';
    }
  };

  return (
    <div className="relative flex items-center justify-center w-64 h-64">
      {/* Outer Glows */}
      {active && (
        <>
          <div className="absolute inset-0 rounded-full bg-blue-500/20 blur-3xl animate-pulse" />
          <div className="absolute inset-4 rounded-full border border-blue-400/30 animate-[spin_10s_linear_infinite]" />
        </>
      )}
      
      {/* Main Orb */}
      <div 
        className={`w-40 h-40 rounded-full bg-gradient-to-tr transition-all duration-300 ease-in-out transform ${getOrbColor()}`}
        style={{ transform: `scale(${scale})` }}
      >
        <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(255,255,255,0.2),transparent)]" />
      </div>
    </div>
  );
};

export default VoiceOrb;
