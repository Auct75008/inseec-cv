
import React, { useState, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { getSystemInstruction, DEFAULT_ARTHUR_CV } from './constants';
import { ConnectionStatus, CVEntry } from './types';
import { decode, decodeAudioData, createPcmBlob } from './services/audioUtils';
import VoiceOrb from './components/VoiceOrb';
import CVManager from './components/CVManager';

const App: React.FC = () => {
  const [status, setStatus] = useState<ConnectionStatus>(ConnectionStatus.IDLE);
  const [cvs, setCvs] = useState<CVEntry[]>([DEFAULT_ARTHUR_CV]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [liveCaption, setLiveCaption] = useState<{text: string, type: 'user' | 'model'} | null>(null);
  const [error, setError] = useState<string | null>(null);

  const audioContextRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);
  
  const captionTimeoutRef = useRef<number | null>(null);

  const addCV = useCallback((newCV: CVEntry) => {
    setCvs(prev => [...prev, newCV]);
  }, []);

  const removeCV = useCallback((id: string) => {
    setCvs(prev => prev.filter(c => c.id !== id));
  }, []);

  const stopConversation = useCallback(() => {
    if (sessionRef.current) sessionRef.current.close?.();
    if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
    sourcesRef.current.forEach(source => source.stop());
    sourcesRef.current.clear();
    setStatus(ConnectionStatus.DISCONNECTED);
    setIsSpeaking(false);
    setLiveCaption(null);
  }, []);

  const startConversation = async () => {
    try {
      setError(null);
      setStatus(ConnectionStatus.CONNECTING);

      if (!process.env.API_KEY) throw new Error("Clé API manquante.");

      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = { input: inputCtx, output: outputCtx };

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } }, 
          },
          systemInstruction: getSystemInstruction(cvs),
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setStatus(ConnectionStatus.CONNECTED);
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              sessionPromise.then((session) => session.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextRef.current) {
              const { output } = audioContextRef.current;
              setIsSpeaking(true);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, output.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), output, 24000, 1);
              const source = output.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(output.destination);
              source.addEventListener('ended', () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              });
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              // Correctly access .current on the sourcesRef object
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.outputTranscription) {
              setLiveCaption({ text: message.serverContent.outputTranscription.text, type: 'model' });
            } else if (message.serverContent?.inputTranscription) {
              setLiveCaption({ text: message.serverContent.inputTranscription.text, type: 'user' });
            }

            if (message.serverContent?.turnComplete) {
              if (captionTimeoutRef.current) window.clearTimeout(captionTimeoutRef.current);
              captionTimeoutRef.current = window.setTimeout(() => setLiveCaption(null), 4000);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
              setIsSpeaking(false);
              setLiveCaption(null);
            }
          },
          onerror: (e) => {
            setError("Eliot a rencontré une erreur de connexion.");
            setStatus(ConnectionStatus.ERROR);
            stopConversation();
          },
          onclose: () => setStatus(ConnectionStatus.DISCONNECTED),
        },
      });
      sessionRef.current = await sessionPromise;
    } catch (err: any) {
      setError(err.message || "Impossible de démarrer.");
      setStatus(ConnectionStatus.ERROR);
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#020617] text-slate-100 font-sans p-4 lg:p-6 overflow-hidden selection:bg-blue-500/30">
      <div className="flex flex-col lg:flex-row w-full h-full gap-6 max-w-[1700px] mx-auto">
        
        {/* CV PANEL */}
        <aside className="w-full lg:w-[450px] flex flex-col bg-slate-900/40 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] p-8 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/5 blur-[60px] rounded-full" />
          
          <div className="flex items-center gap-5 mb-10 relative z-10">
            <div className="relative group">
              <img src="https://picsum.photos/seed/arthur/200/200" alt="Arthur" className="w-20 h-20 rounded-3xl object-cover grayscale brightness-110 transition-all group-hover:grayscale-0 group-hover:scale-105 duration-500 shadow-xl" />
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-4 border-[#020617]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white">Arthur Picard</h1>
              <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.2em]">Assistant Digital Eliot</p>
            </div>
          </div>
          
          <div className="flex-1 overflow-hidden relative z-10">
            <CVManager cvs={cvs} onAdd={addCV} onRemove={removeCV} />
          </div>

          <div className="mt-8 pt-6 border-t border-white/5 relative z-10">
             <div className="flex items-center gap-4 text-slate-500">
               <div className="p-2 bg-white/5 rounded-xl">
                 <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                 </svg>
               </div>
               <p className="text-[10px] leading-relaxed font-medium uppercase tracking-wider opacity-60">
                 Confidentialité garantie. Aucune donnée n'est stockée hors session.
               </p>
             </div>
          </div>
        </aside>

        {/* INTERACTION AREA */}
        <main className="flex-1 flex flex-col relative">
          <div className="flex-1 flex flex-col items-center justify-center bg-slate-900/10 backdrop-blur-2xl border border-white/5 rounded-[3rem] overflow-hidden shadow-inner relative group transition-all duration-700">
            
            {/* Ambient Background Glows */}
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-blue-600/10 blur-[150px] rounded-full animate-pulse" />
              <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-indigo-600/10 blur-[150px] rounded-full" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[80%] bg-blue-500/[0.02] blur-[100px] rounded-full" />
            </div>

            <div className="z-10 flex flex-col items-center gap-14 w-full max-w-2xl text-center px-10">
              <div className="relative">
                <VoiceOrb active={isSpeaking || status === ConnectionStatus.CONNECTED} status={status} />
                {status === ConnectionStatus.CONNECTED && !isSpeaking && (
                   <div className="absolute -top-4 -right-4 px-3 py-1 bg-white/5 backdrop-blur-md border border-white/10 rounded-full text-[10px] font-bold text-blue-400 uppercase tracking-widest animate-bounce">
                     En écoute
                   </div>
                )}
              </div>
              
              <div className="space-y-6">
                <h3 className="text-5xl font-extralight tracking-tight text-white/95 leading-tight">
                  {status === ConnectionStatus.IDLE && "Eliot est à votre écoute."}
                  {status === ConnectionStatus.CONNECTING && "Initialisation..."}
                  {status === ConnectionStatus.CONNECTED && (isSpeaking ? "Eliot vous répond" : "Comment puis-je vous aider ?")}
                  {status === ConnectionStatus.ERROR && "Erreur de connexion"}
                </h3>
                <p className="text-slate-500 text-xl font-light max-w-sm mx-auto leading-relaxed">
                  {status === ConnectionStatus.IDLE && "Appuyez ci-dessous pour démarrer une session vocale."}
                  {status === ConnectionStatus.CONNECTED && "Je connais parfaitement le parcours d'Arthur."}
                </p>
              </div>

              <div className="relative mt-4">
                {status === ConnectionStatus.IDLE || status === ConnectionStatus.DISCONNECTED || status === ConnectionStatus.ERROR ? (
                  <button 
                    onClick={startConversation}
                    className="group relative flex items-center gap-4 px-12 py-6 bg-white text-slate-950 rounded-[2rem] font-black uppercase tracking-widest text-sm transition-all hover:scale-105 active:scale-95 shadow-[0_25px_50px_rgba(255,255,255,0.15)] hover:shadow-white/25 active:shadow-none"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M7 4a3 3 0 016 0v6a3 3 0 11-6 0V4z" />
                      <path fillRule="evenodd" d="M3 10a7 7 0 017-7V1a1 1 0 112 0v2a7 7 0 017 7v1a1 1 0 11-2 0v-1a5 5 0 00-10 0v1a1 1 0 11-2 0v-1z" clipRule="evenodd" />
                    </svg>
                    Démarrer Eliot
                  </button>
                ) : (
                  <button 
                    onClick={stopConversation}
                    className="group px-12 py-6 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-[2rem] font-black uppercase tracking-widest text-sm transition-all border border-red-500/30 flex items-center gap-4"
                  >
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse group-hover:scale-125 transition-transform" />
                    Quitter la session
                  </button>
                )}
              </div>
            </div>

            {/* LIVE CAPTIONS (Transient) */}
            {liveCaption && (
              <div className="absolute bottom-16 left-1/2 -translate-x-1/2 w-full max-w-3xl px-12 transition-all animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div className={`p-8 rounded-[2.5rem] border backdrop-blur-3xl shadow-[0_40px_80px_rgba(0,0,0,0.5)] ${
                  liveCaption.type === 'user' 
                    ? 'bg-blue-600/10 border-blue-500/30 text-blue-50' 
                    : 'bg-white/5 border-white/10 text-white/90'
                }`}>
                  <div className="flex items-start gap-4">
                    <div className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${liveCaption.type === 'user' ? 'bg-blue-400' : 'bg-slate-500'}`} />
                    <p className="text-xl leading-relaxed font-light italic text-left">
                      {liveCaption.text}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
